import { Header } from './components/header'
import { MatchmakingNetworkGrid } from './components/matchmaking-network-grid'
import { Button } from "@/components/ui/button"

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-rose-100 to-teal-100 dark:from-gray-900 dark:to-gray-800">
      <Header />
      <main className="flex-grow">
        <div className="container mx-auto px-4 py-12 text-center">
          <h1 className="text-4xl font-bold mb-4 text-gray-800 dark:text-gray-200">Find Your Perfect Match</h1>
          <p className="text-xl mb-8 text-gray-600 dark:text-gray-400">Explore our network of top dating sites and start your journey to love.</p>
          <Button className="bg-rose-600 hover:bg-rose-700 text-white font-bold py-2 px-4 rounded dark:bg-rose-500 dark:hover:bg-rose-600">
            Get Started
          </Button>
        </div>
        <MatchmakingNetworkGrid />
      </main>
    </div>
  )
}

