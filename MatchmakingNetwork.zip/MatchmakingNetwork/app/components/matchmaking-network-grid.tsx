'use client'

import Image from 'next/image'
import { Card, CardContent } from "@/components/ui/card"
import { motion } from 'framer-motion'

interface MatchmakingSite {
  name: string;
  logo: string;
}

const matchmakingSites: MatchmakingSite[] = [
  { name: "Match.com", logo: "/logos/match.png" },
  { name: "eHarmony", logo: "/logos/eharmony.png" },
  { name: "OkCupid", logo: "/logos/okcupid.png" },
  { name: "Tinder", logo: "/logos/tinder.png" },
  { name: "Bumble", logo: "/logos/bumble.png" },
  { name: "Hinge", logo: "/logos/hinge.png" },
  { name: "Plenty of Fish", logo: "/logos/pof.png" },
  { name: "Zoosk", logo: "/logos/zoosk.png" },
  { name: "Coffee Meets Bagel", logo: "/logos/cmb.png" },
  { name: "EliteSingles", logo: "/logos/elitesingles.png" },
  { name: "Christian Mingle", logo: "/logos/christianmingle.png" },
  { name: "Silver Singles", logo: "/logos/silversingles.png" },
]

export function MatchmakingNetworkGrid() {
  return (
    <div className="container mx-auto px-4 py-8">
      <motion.h2 
        className="text-3xl font-bold text-center mb-4 text-gray-800 dark:text-gray-200"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        Our Matchmaking Network
      </motion.h2>
      <motion.p 
        className="text-center text-gray-600 dark:text-gray-400 mb-8"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.2 }}
      >
        Discover our diverse range of matchmaking services tailored to help you find meaningful connections.
      </motion.p>
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {matchmakingSites.map((site, index) => (
          <motion.div
            key={site.name}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.3, delay: index * 0.1 }}
          >
            <Card className="hover:shadow-lg transition-shadow duration-300 group bg-white dark:bg-gray-800">
              <CardContent className="flex flex-col items-center justify-center p-4">
                <div className="relative w-20 h-20 mb-2 overflow-hidden rounded-full">
                  <Image
                    src={site.logo}
                    alt={`${site.name} logo`}
                    layout="fill"
                    objectFit="cover"
                    className="transition-transform duration-300 group-hover:scale-110"
                  />
                </div>
                <h3 className="text-lg font-semibold text-center group-hover:text-rose-600 dark:group-hover:text-rose-400 transition-colors duration-300 text-gray-800 dark:text-gray-200">{site.name}</h3>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>
    </div>
  )
}

